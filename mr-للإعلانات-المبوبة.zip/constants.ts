
export const PLATFORMS = [
  "Facebook",
  "Instagram",
  "Google Ads",
  "X (Twitter)",
  "LinkedIn",
  "TikTok",
  "Snapchat"
];

export const TONES = [
  "احترافي",
  "ودود",
  "فكاهي",
  "مقنع",
  "رسمي",
  "جريء",
  "عاطفي"
];