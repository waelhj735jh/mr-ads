
import { GoogleGenAI, Type } from "@google/genai";
import type { AdFormData, GeneratedAd } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const adSchema = {
  type: Type.OBJECT,
  properties: {
    headline: {
      type: Type.STRING,
      description: 'عنوان إعلاني جذاب وقصير لا يتجاوز 10 كلمات.',
    },
    body: {
      type: Type.STRING,
      description: 'نص الإعلان الرئيسي الذي يصف المنتج وفوائده. يجب أن يكون بين 30 و 50 كلمة.',
    },
    callToAction: {
      type: Type.STRING,
      description: 'دعوة واضحة لاتخاذ إجراء مثل "تسوق الآن" أو "اعرف المزيد".',
    },
  },
  required: ["headline", "body", "callToAction"],
};

export const generateAdCopy = async (formData: AdFormData): Promise<GeneratedAd[]> => {
  const { productName, targetAudience, platform, tone, features } = formData;

  const prompt = `
    أنت خبير تسويق رقمي متخصص في كتابة الإعلانات المقنعة. مهمتك هي إنشاء 3 أفكار إعلانية فريدة ومختلفة لمنصة ${platform}.

    الرجاء استخدام التفاصيل التالية لإنشاء الإعلانات:
    - اسم المنتج: ${productName}
    - الجمهور المستهدف: ${targetAudience}
    - الميزات/الفوائد الرئيسية: ${features}
    - نبرة الصوت المطلوبة: ${tone}

    يجب أن تكون كل فكرة إعلانية متكاملة وتحتوي على عنوان جذاب، نص رئيسي، ودعوة واضحة لاتخاذ إجراء.
    تأكد من أن كل إعلان فريد ويستهدف زاوية تسويقية مختلفة.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: adSchema,
        },
      },
    });
    
    const jsonText = response.text.trim();
    if (!jsonText) {
        throw new Error("Received an empty response from the API.");
    }

    const generatedAds: GeneratedAd[] = JSON.parse(jsonText);
    return generatedAds;
  } catch (error) {
    console.error("Error generating ad copy:", error);
    throw new Error("Failed to generate ad copy from Gemini API.");
  }
};
